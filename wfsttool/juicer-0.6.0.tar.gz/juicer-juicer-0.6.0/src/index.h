/** \mainpage

This is the documentation for the Juicer decoder.

@author Darren Moore <moore@idiap.ch>.  Original WFST decoder and tools.
@author Octavian Cheng <ocheng@idiap.ch>.  On the fly decoder.
@author Phil Garner <Phil.Garner@idiap.ch>.  We'll see...
 
*/
