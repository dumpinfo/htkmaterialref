/*
 * Copyright 2009 by Idiap Research Institute
 *                   http://www.idiap.ch
 *
 * See the file COPYING for the licence associated with this software.
 */

#ifndef SIGNAL_H
#define SIGNAL_H

namespace Tracter
{
    void TrapFPE();
}

#endif /* SIGNAL_H */
